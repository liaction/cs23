# virtual-packages-list-generator
Arch Linux virtual packages list generator for use with debtap
